#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define V 8

char locations[V][20] = {
    "Main Gate", "Library", "Block 1", "Block 2",
    "Cafeteria", "Auditorium", "Parking", "Lab"
};

struct Node {
    int vertex;
    struct Node *next;
};

struct Node *graph[V];

void addEdge(int u, int v) {
    struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->vertex = v;
    newNode->next = graph[u];
    graph[u] = newNode;

    newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->vertex = u;
    newNode->next = graph[v];
    graph[v] = newNode;
}

void createGraph() {
    int i;
    for (i = 0; i < V; i++)
        graph[i] = NULL;

    addEdge(0, 1);
    addEdge(0, 2);
    addEdge(1, 3);
    addEdge(1, 4);
    addEdge(2, 3);
    addEdge(2, 6);
    addEdge(3, 7);
    addEdge(4, 5);
    addEdge(5, 6);
    addEdge(6, 7);
}

void displayLocations() {
    int i;
    printf("\n===== CAMPUS LOCATIONS =====\n");
    for (i = 0; i < V; i++)
        printf("%d. %s\n", i, locations[i]);
}

void bfs(int source, int destination) {
    int visited[V] = {0}, parent[V], queue[V];
    int front = 0, rear = 0, i, current;
    int path[V], count = 0;

    for (i = 0; i < V; i++)
        parent[i] = -1;

    visited[source] = 1;
    queue[rear++] = source;

    while (front < rear) {
        current = queue[front++];

        if (current == destination)
            break;

        struct Node *temp = graph[current];
        while (temp != NULL) {
            int next = temp->vertex;
            if (!visited[next]) {
                visited[next] = 1;
                parent[next] = current;
                queue[rear++] = next;
            }
            temp = temp->next;
        }
    }

    if (!visited[destination]) {
        printf("\nNo route found between %s and %s.\n",
               locations[source], locations[destination]);
        return;
    }

    current = destination;
    while (current != -1) {
        path[count++] = current;
        current = parent[current];
    }

    printf("\nShortest route using BFS:\n");
    for (i = count - 1; i >= 0; i--) {
        printf("%s", locations[path[i]]);
        if (i > 0)
            printf(" -> ");
    }
    printf("\nNumber of edges: %d\n", count - 1);
}

void dfsVisit(int vertex, int visited[]) {
    visited[vertex] = 1;
    printf("%s\n", locations[vertex]);

    struct Node *temp = graph[vertex];
    while (temp != NULL) {
        if (!visited[temp->vertex])
            dfsVisit(temp->vertex, visited);
        temp = temp->next;
    }
}

void findReachable(int source) {
    int visited[V] = {0};
    int i;

    printf("\nReachable locations from %s:\n", locations[source]);
    dfsVisit(source, visited);

    printf("\nDisconnected locations:\n");
    for (i = 0; i < V; i++) {
        if (!visited[i])
            printf("%s\n", locations[i]);
    }

    int found = 0;
    for (i = 0; i < V; i++)
        if (!visited[i])
            found = 1;

    if (!found)
        printf("No disconnected locations. All locations are reachable.\n");
}

int main() {
    int choice, source, destination, i;

    createGraph();

    while (1) {
        printf("\n========== CAMPUS ROUTE FINDER ==========\n");
        printf("1. Display Campus Locations\n");
        printf("2. Find Shortest Route (BFS)\n");
        printf("3. Find Reachable Locations (DFS)\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input.\n");
            return 0;
        }

        if (choice == 1) {
            displayLocations();
        } else if (choice == 2) {
            displayLocations();
            printf("\nEnter source location number: ");
            scanf("%d", &source);
            printf("Enter destination location number: ");
            scanf("%d", &destination);

            if (source < 0 || source >= V || destination < 0 || destination >= V)
                printf("Invalid location number! Use 0 to 7.\n");
            else
                bfs(source, destination);
        } else if (choice == 3) {
            displayLocations();
            printf("\nEnter starting location number: ");
            scanf("%d", &source);

            if (source < 0 || source >= V)
                printf("Invalid location number! Use 0 to 7.\n");
            else
                findReachable(source);
        } else if (choice == 4) {
            printf("Thank you for using Campus Route Finder.\n");
            break;
        } else {
            printf("Invalid choice. Please try again.\n");
        }
    }

    for (i = 0; i < V; i++) {
        struct Node *temp = graph[i];
        while (temp != NULL) {
            struct Node *next = temp->next;
            free(temp);
            temp = next;
        }
    }

    return 0;
}
