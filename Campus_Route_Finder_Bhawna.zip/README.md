# Campus Route Finder Using Graphs

**Student Name:** Bhawna  
**Language:** C  
**Subject:** Data Structures and Algorithms (DSA)

## Project Description
Campus Route Finder represents eight campus locations as vertices of an undirected graph. Paths between locations are represented as edges. The program uses an adjacency list to store the graph.

## Campus Locations
| Number | Location |
|---:|---|
| 0 | Main Gate |
| 1 | Library |
| 2 | Block 1 |
| 3 | Block 2 |
| 4 | Cafeteria |
| 5 | Auditorium |
| 6 | Parking |
| 7 | Lab |

## Features
1. Display all campus locations.
2. Find the shortest route between two locations using Breadth-First Search (BFS).
3. Display reachable locations using Depth-First Search (DFS).
4. Identify disconnected locations.
5. Check invalid location numbers.

## Files
- `main.c` — complete C source code.
- `README.md` — project information and instructions.
- `Report.pdf` — project report.
- `test_cases.txt` — test cases and expected results.

## How to Compile and Run

### GCC (Windows/Linux)
Open a terminal in this folder and run:

```bash
gcc main.c -o campus_route_finder
```

On Windows:
```bash
campus_route_finder.exe
```

On Linux/macOS:
```bash
./campus_route_finder
```

You can also open `main.c` in Code::Blocks, Dev-C++, or VS Code with a C compiler installed.

## Sample Test
- Select option `2`.
- Enter source `0` (Main Gate).
- Enter destination `5` (Auditorium).
- The program displays a shortest route with 3 edges.

## Algorithms and Complexity
Let V be the number of vertices and E be the number of edges.

- BFS using an adjacency list: O(V + E) time.
- DFS using an adjacency list: O(V + E) time.
- Adjacency-list storage: O(V + E) space.
- BFS queue, visited and parent arrays: O(V) extra space.
- DFS visited array and recursion stack: O(V) extra space.

## Graph Connections
Main Gate—Library, Main Gate—Block 1, Library—Block 2, Library—Cafeteria, Block 1—Block 2, Block 1—Parking, Block 2—Lab, Cafeteria—Auditorium, Auditorium—Parking, Parking—Lab.

## GitHub
Create a new public or private repository named `Campus-Route-Finder`. Upload `main.c`, `README.md`, `Report.pdf`, and `test_cases.txt`.
